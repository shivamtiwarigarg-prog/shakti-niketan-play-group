SHAKTI NIKETAN PLAY GROUP — ANDROID APP PROJECT

This is an Android Studio project that packages the finished offline school portal as a native Android app using WebView.

Owner:
ID: Shivam6330@
Password: Shivam8707

Demo:
Teacher: teacher / teacher123
Parent: parent / parent123

How to build the APK:
1. Install Android Studio on a computer.
2. Open this project folder.
3. Let Gradle sync.
4. Build > Build APK(s).
5. The APK will be generated under:
   app/build/outputs/apk/debug/app-debug.apk

The app works offline. School data is stored in the app's WebView local storage.
